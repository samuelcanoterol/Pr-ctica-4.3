package reviews.main;
import java.util.Arrays;

import reviews.data.*;

public class Management {
    static User[] us;
    static Business[] bi;
    public void initialize()
    {
        us = new User[10];
        us[0]=new User("login1","password1");
        us[1]=new User("login2","password2");
        us[2]=new User("login3","password3");
        us[3]=new User("login4","password4");
        us[4]=new User("login5","password5");
        us[5]=new User("login6","password6");
        us[6]=new User("login7","password7");
        us[7]=new User("login8","password8");
        us[8]=new User("login9","password9");
        us[9]=new User("login10","password10");



        bi= new Business[6];
        bi[0]=new Restaurant("Business1","location1","mexican", new Review[]{new Review(us[0],"good", 5),new Review(us[6],"good", 5)});
        bi[0]=new Restaurant("Business1","location1","mexican", new Review[]{new Review(us[1],"good", 4),new Review(us[5],"good", 5)});
        bi[2]=new Hairdresser("Business3","location3",true, new Review[]{new Review(us[2],"bad", 1),new Review(us[6],"good", 5)});
        bi[3]=new Hairdresser("Business4","location4",false, new Review[]{new Review(us[3],"good", 3),new Review(us[7],"good", 5)});
        bi[4]=new Garage("Business5","location5",100, new Review[]{new Review(us[4],"good", 4),new Review(us[8],"good", 5)});
        bi[5]=new Garage("Business6","location6",200, new Review[]{new Review(us[5],"bad", 3),new Review(us[9],"good", 5)});
    }
    public User userlogin(String login, String password) {
        for (int i = 0; i < us.length; i++) {
            if (login.equals(us[i].getLogin()) && password.equals(us[i].getPassword()))
            {
                return us[i];
            }
        }
        return null;
    }



    public static void showReviews(User user)
    {
        for (int i = 0; i < bi.length; i++) {
            for (int j = 0; j < bi[i].getReviews().length; j++)
            {
                if (bi[i].getReviews()[j].getUser().equals(user))
                {
                     System.out.println(bi[i].getReviews()[j]);;
                }

            }
        }

    }
    public static void sortBusinessesByName()
    {
        Arrays.sort(bi);
        for (int i = 0; i < bi.length; i++) {
            bi[i].toString();
        }

    }
    public static void sortBusinessesByRating(int type)
    {

        for (int i = 0; i < bi.length; i++)
        {
            for (int j = 0; j < bi.length - i - 1; j++)
            {
                if (bi[j].reviewAverage() > bi[j+1].reviewAverage())
                {
                    Business auxiliar = bi[j];
                    bi[j] = bi[j];
                    bi[j+1] = auxiliar;
                }
            }
        }


    }
    public Business findBusiness(String name)
    {
        for (int i = 0; i < bi.length; i++) {
            if (name.equals(bi[i].getName()))
            {
                return bi[i];
            }
        }
        return null;
    }
    public Review findReview(User user, Business business)
    {

        for (int i = 0; i < bi.length; i++) {
            if (bi[i].equals(business)) {
                for (int j = 0; j < bi[i].getReviews().length; j++) {
                    if (bi[i].getReviews()[j].getUser().equals(user)) {
                        return (bi[i].getReviews()[j]);

                    }

                }
            }
        }

        return null;
    }
    /*static void changeReview(Review r, String comment, int rating) {

        r=new Review(userlogin(),comment, rating);
    }*/
}
