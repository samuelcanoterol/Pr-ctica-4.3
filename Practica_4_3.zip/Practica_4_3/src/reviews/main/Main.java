package reviews.main;
import reviews.data.Business;
import reviews.data.Review;
import reviews.data.User;

import java.util.Random;
import java.util.Scanner;
public class Main {

    public static void main() {
        Scanner sc = new Scanner(System.in);
        Management management = new Management();
        System.out.println("Escribe el nombre del usuario");
        String usuario = sc.nextLine();
        System.out.println("Escribe la contraseña del usuario");
        String contrasenya = sc.nextLine();
        User us =  management.userlogin(usuario,contrasenya);

        int opcion = 0;

        do
        {
            System.out.println("Menu de opciones");
            System.out.println("1. My reviews");
            System.out.println("1. Business list");
            System.out.println("1. Top rated businesses");
            System.out.println("4. Edit my review");
            System.out.println("5. Quit");
            opcion= sc.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Escribe el nombre del usuario");
                    String nombre = sc.nextLine();
                    Management.showReviews(us);
                    break;
                case 2:
                    Management.sortBusinessesByName();

                    break;
                case 3:
                    System.out.println("Escribe el tipo");
                    int tipo=sc.nextInt();
                    Management.sortBusinessesByRating(tipo);
                    break;
                case 4:
                    /*Management.findBusiness(String nombre);
                    Review findReview(us, findBusiness);
                    Management.changeReview(r, comentario, valoracion);*/
                    break;
                case 5:
                    System.out.println("Fin del programa");
                    break;
                default:
                    System.out.println("Opción incorrecta");
                    break;
            }
        }
        while (opcion != 5);

    }


}
