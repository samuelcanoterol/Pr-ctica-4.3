package reviews.data;

public class Garage extends Business {

    private float price;

    public Garage(String name, String location, float price,Review[] reviews) {
        super(name, location,reviews);
        this.price = price;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String toString() {
        return  super.toString() + " - " + price  + "eur/h";
    }
}
