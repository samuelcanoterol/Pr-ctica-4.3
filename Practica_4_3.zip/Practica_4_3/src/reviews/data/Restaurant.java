package reviews.data;

public class Restaurant extends Business {
    private String foodtype;

    public Restaurant(String name, String location,String foodtype, Review[] reviews) {
        super(name, location, reviews);
        this.foodtype = foodtype;
    }

    public String getFoodtype() {
        return foodtype;
    }

    public void setFoodtype(String foodtype) {
        this.foodtype = foodtype;
    }

    @Override
    public String toString() {
        return  super.toString() + " - " + foodtype +"\n"+"Review average: ";
    }
}
