package reviews.data;

public class Business implements Comparable<Business> {
    protected String name;
    protected String location;
    protected Review[] reviews;

    public Business(String name, String location, Review[] reviews) {
        this.name = name;
        this.location = location;
        this.reviews = reviews;
    }
    public int reviewAverage()
    {
        int aux=0;
        for(int i=0; i< reviews.length; i++)
        {
            aux+=reviews[i].getRating();
        }
        return aux/reviews.length;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Review[] getReviews() {
        return reviews;
    }

    public void setReviews(Review[] reviews) {
        this.reviews = reviews;
    }

    @Override
    public String toString() {
        return  name + " (" + location + ")";
    }

    @Override
    public int compareTo(Business o) {
        if(o.name.charAt(0)<this.name.charAt(0))
        {
            return 1;
        }
        else if(o.name.charAt(0)>this.name.charAt(0))
        {
            return -1;
        }

        return 0;
    }
}
